package com.senvon.sample.service;

public interface LoadCallback<T> {

	public T load();
}
